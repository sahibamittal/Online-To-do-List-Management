class ApplicationMailer < ActionMailer::Base
  default from: 'sahibamittal98@gmail.com'
  layout 'mailer'
end
