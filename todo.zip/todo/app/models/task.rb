class Task < ApplicationRecord
  belongs_to :user
end
