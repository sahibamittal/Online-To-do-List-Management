Rails.application.routes.draw do
  resources :shared_tasks
  get 'tasks/show'
  get 'tasks/create'
  get 'tasks/edit'
  get 'tasks/delete'
  get 'tasks/share'
  get 'credentials/signup'
  get 'credentials/login'
  get 'welcome/main'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
