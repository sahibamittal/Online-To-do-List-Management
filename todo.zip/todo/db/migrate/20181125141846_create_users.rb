class CreateUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.string :fname, null: false
      t.string :lname
      t.integer :age
      t.string :username, null: false
      t.string :password, null: false
      t.string :email_id, null: false
      t.timestamps
    end
  end
end
