require 'test_helper'

class SharedTasksControllerTest < ActionDispatch::IntegrationTest
  setup do
    @shared_task = shared_tasks(:one)
  end

  test "should get index" do
    get shared_tasks_url
    assert_response :success
  end

  test "should get new" do
    get new_shared_task_url
    assert_response :success
  end

  test "should create shared_task" do
    assert_difference('SharedTask.count') do
      post shared_tasks_url, params: { shared_task: { description: @shared_task.description, name: @shared_task.name, priority: @shared_task.priority } }
    end

    assert_redirected_to shared_task_url(SharedTask.last)
  end

  test "should show shared_task" do
    get shared_task_url(@shared_task)
    assert_response :success
  end

  test "should get edit" do
    get edit_shared_task_url(@shared_task)
    assert_response :success
  end

  test "should update shared_task" do
    patch shared_task_url(@shared_task), params: { shared_task: { description: @shared_task.description, name: @shared_task.name, priority: @shared_task.priority } }
    assert_redirected_to shared_task_url(@shared_task)
  end

  test "should destroy shared_task" do
    assert_difference('SharedTask.count', -1) do
      delete shared_task_url(@shared_task)
    end

    assert_redirected_to shared_tasks_url
  end
end
