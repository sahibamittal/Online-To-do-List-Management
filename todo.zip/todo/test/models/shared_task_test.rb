require 'test_helper'

class SharedTaskTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
