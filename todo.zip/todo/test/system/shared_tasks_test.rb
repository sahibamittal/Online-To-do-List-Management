require "application_system_test_case"

class SharedTasksTest < ApplicationSystemTestCase
  setup do
    @shared_task = shared_tasks(:one)
  end

  test "visiting the index" do
    visit shared_tasks_url
    assert_selector "h1", text: "Shared Tasks"
  end

  test "creating a Shared task" do
    visit shared_tasks_url
    click_on "New Shared Task"

    fill_in "Description", with: @shared_task.description
    fill_in "Name", with: @shared_task.name
    fill_in "Priority", with: @shared_task.priority
    click_on "Create Shared task"

    assert_text "Shared task was successfully created"
    click_on "Back"
  end

  test "updating a Shared task" do
    visit shared_tasks_url
    click_on "Edit", match: :first

    fill_in "Description", with: @shared_task.description
    fill_in "Name", with: @shared_task.name
    fill_in "Priority", with: @shared_task.priority
    click_on "Update Shared task"

    assert_text "Shared task was successfully updated"
    click_on "Back"
  end

  test "destroying a Shared task" do
    visit shared_tasks_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Shared task was successfully destroyed"
  end
end
